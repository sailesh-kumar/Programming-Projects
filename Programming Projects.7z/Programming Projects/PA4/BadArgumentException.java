
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 */
public class BadArgumentException extends IOException {
    public BadArgumentException(){
    }
    public BadArgumentException(String message){
       super(message);
       System.out.println("The java Run command should look like this: java GenText [-d] prefixLength numWords sourceFile outFile ");
        
    }
    
}
