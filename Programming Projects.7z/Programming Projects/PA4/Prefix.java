
import java.util.ArrayList;
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 */
public class Prefix {

    private static RandomTextGenerator mapObject = new RandomTextGenerator();

    /*The getPrefix method returns a new prefix of Prefixlength words everytime it is called*/
    public static ArrayList<String> getPrefix(ArrayList<String> newPrefix, String word) {
        if(!word.equals("")){
        newPrefix.add(word);// add the previously generated word
        newPrefix.remove(0);// remove the first word in prefix
        }
        return newPrefix;     
    }

    public static ArrayList<String> getPrefixFresh(int length) {

        Random rand = new Random();
        ArrayList<String> newPrefix = new ArrayList<String>();
        ArrayList<ArrayList<String>> keylist = new ArrayList<ArrayList<String>>(mapObject.getKeySet());
        if(GenText.getDebugState() == 1)
        {
            newPrefix = (keylist.get(rand.nextInt(1)));
        }
        else {
            newPrefix = (keylist.get(rand.nextInt(mapObject.getSize())));//choose a random sequence from the map
        }    
        ArrayList<String> n1 = new ArrayList<String>();
        for(String t: newPrefix)
        {
            n1.add(t);
        }
        return n1;
    }
}
