
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.ListIterator;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author Nishant Parikh
 */
public class RandomTextGenerator {

    public RandomTextGenerator() {
    }

    private static boolean initialcall = true;
    private static ArrayList<String> prefix;  
    private static HashMap<ArrayList<String>, ArrayList<String>> map;
    private static ListIterator iterkey;
    private static ListIterator iter2;
    private static ArrayList<String> arraylist;
    private static ArrayList<String> str;
    private static String word = "";

    /**
     * @param in
     * @param args the command line arguments The constructor creates a hashmap
     * with keyType as the prefixLength of words in the file and ValueType as
     * the successors of the prefix.
     */
    public RandomTextGenerator(Scanner in, int length) {
        prefix = new ArrayList<String>();
        arraylist = new ArrayList<String>();
        map = new HashMap<ArrayList<String>, ArrayList<String>>();
        while (in.hasNext()) {
            arraylist.add(in.next());// form an arraylist of all contents of the file
        }
        iterkey = arraylist.listIterator();
        while (iterkey.hasNext()) {// form the hashmap
            str = new ArrayList<String>();
            for (int i = 0; i < length; i++) {
                if (iterkey.hasNext()) {
                    str.add((String) iterkey.next());
                }
            }
            map.put(str, successorWords(str, arraylist));
            for (int i = 0; i < str.size() - 1; i++) {
                if (iterkey.hasNext()) {
                    iterkey.previous();
                }
            }

        }
    }
    /*successorWords is a private method that the RandomTextGenerator constructor calls.
     This method returns  the word following the prefixlength of words in the input file */

    private static ArrayList<String> successorWords(ArrayList<String> string, ArrayList<String> list) {
        ArrayList<String> arr = new ArrayList<String>();
        ListIterator iterator = list.listIterator();
        String one, two;
        while (iterator.hasNext()) {
            iter2 = string.listIterator();
            int consecutive = 0;
            while (iter2.hasNext() && iterator.hasNext()) {
                one = (String) iter2.next();
                two = (String) iterator.next();
                if (one.equals(two)) {
                    consecutive++;
                }
            }
            if (consecutive == string.size()) {
                if (iterator.hasNext()) {
                    arr.add((String) iterator.next());
                    iterator.previous();
                }
            } else {
                for (int j = 0; j < string.size() - 1; j++) {
                    if (iterator.hasNext()) {
                        iterator.previous();
                    }
                }
            }
        }
        return arr;
    }
   
    private static String ArrayListToString(ArrayList<String> A) {
        String str = "";
        for (String s : A) {
            str += s + " ";
        }
        return str;
    }
 /* The randomTextGen method returns a word text everytime it is called*/
    public static String randomTextGen(int length) {
        boolean lastOccurence = false;
        if (map.containsKey(prefix)) {
            lastOccurence = (map.get(prefix)).isEmpty();//if map has no mapping of the current prefix, then it is the last occurence
        }
        if (initialcall | lastOccurence) {
            prefix = Prefix.getPrefixFresh(length);
            if (GenText.getDebugState() == 1) {
                System.out.println("DEBUG: chose a new initial prefix:" + ArrayListToString(prefix));
            }
        } else {
            prefix = Prefix.getPrefix(prefix, word);
        }
        ArrayList<String> value = new ArrayList<String>();

        if (map.containsKey(prefix)) {
            value = map.get(prefix);
        }
        Random randWord = new Random();
        if (value.size() == 1) {
            word = value.get(value.size() - 1);
        } else if (value.size() > 1) {
            if (GenText.getDebugState() == 1) {
                word = value.get(randWord.nextInt(1));
            } else {
                word = value.get(randWord.nextInt(value.size()));
            }
        } else {
            word = "";
        }
if(GenText.getDebugState()==1){
        if (!word.equals("")) {
            if (!(initialcall | lastOccurence)) {
                System.out.println("DEBUG: prefix:" + ArrayListToString(prefix));
            }
            System.out.println("DEBUG: successors:" + ArrayListToString(value));
        } else {
            System.out.println("DEBUG: successors: <END OF FILE>");
        }}
        initialcall = false;
        return word;
    }

    public static ArrayList<String> getEntry(ArrayList<String> key) {
        final ArrayList<String> temp=map.get(key);
        return temp;
    }

    public static int getSize() {
        return map.size();
    }

    public static Set<ArrayList<String>> getKeySet() {
        final Set<ArrayList<String>> temp=map.keySet();
        return temp;
    }
}
