
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Nishant Parikh
 */
public class GenText {

    private static RandomTextGenerator text;
    private static int prefixLength = 0;
    private static int numWords = 0;
    private static String infile, outfile;
    private static int debugmode = 0;
    private static final int LIMIT = 80;
    private static int i = -1;

    public static void main(String[] args) throws IOException {

        Scanner in = null;
        File file = null;
        FileReader filename = null;
        try {
            if (args.length != 4) {
                if (args.length == 5) {
                    if (args[0].compareTo("-d") == 0) {
                        debugmode = 1;
                    }
                } else {
                    throw new BadArgumentException("missing command-line arguments");
                }
            }
            prefixLength = Integer.parseInt(args[0 + debugmode]);
            if (prefixLength < 1) {
                System.out.println("where the prefixLength should be greater than 1");
                throw new BadArgumentException("prefixLength < 1");
            }
            numWords = Integer.parseInt(args[1 + debugmode]);
            if (numWords < 0) {
                System.out.println("where the numWords should be greater than 0");
                throw new BadArgumentException("numWords < 0");
            }
            infile = args[2 + debugmode];
            outfile = args[3 + debugmode];
            file = new File(infile);
            filename = new FileReader(file);
            in = new Scanner(filename);
            text = new RandomTextGenerator(in, prefixLength);//creates the hashmap
            File outf = new File(outfile);
            BufferedWriter output = new BufferedWriter(new FileWriter(outf));

            for (int i = 0; i < numWords; i++) {
                writeFile(outfile, output);
            }
            output.close();
        } catch (NumberFormatException e) {
            System.out.println("prefixLength or numWords arguments are not integers");
            System.out.println("The java Run command should look like: java GenText [-d] prefixLength numWords sourceFile outFile ");
            System.out.println("where prefixLength and numWords are integers ");
        } catch (FileNotFoundException exc) {
            System.out.println("input file does not exist");
        }  finally {
            try {
                if (filename != null) {
                    filename.close();
                }
            } catch (IOException exception) {
                System.out.println("i/o exc");//exception.printStackTrace();
            }
        }

    }
    public static void writeFile(String filename, BufferedWriter output) {

        try {
            String generatedtext = text.randomTextGen(prefixLength);
            while (generatedtext == "") {
                generatedtext = text.randomTextGen(prefixLength);
            }
            i = i + generatedtext.length() + 1;             
            if (i / LIMIT >= 1) {
                output.newLine();
                i = generatedtext.length();
            }
            output.write(generatedtext + " ");

        } catch (IOException ex) {
            System.out.println("Can't write to output file");
        }
    }
    public static int getDebugState(){
        return debugmode;
    }
}
