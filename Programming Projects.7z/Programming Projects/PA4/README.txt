Initially all the dat from spurse file was copied into an arraylist.Hash Map data structure was the used to store the successors of the prefixLength word sequences as they appear in the source text. 
1) HashMap is created.
   Key = sequence of words in ArrayList ( sequence length = no. provided in argument)
   Value = ArrayList of successive words appearing after key, repeated words will be added multiple times depending on their occurance.
2) either random number[0-size of(Hashmap)) is generated to start with or in debug mode it will start with 1.
   If the last prefix is generated then repeat generating prefixes until some other prefix is generated.   
   2.1) random number is generated to select the successor from value(ArrayList) of the selected key.
3) Iterate till the number provided in argument.
   3.1) delete first word in arraylist and append newly generated successor in arraylist.
   3.2) If the last prefix is generated then repeat generating prefixes until some other prefix is generated.   
   3.3) use that as key and generate to select the successor from value(ArrayList) of the selected key.