// Name:Sailesh Kumar Kumar
// Loginid:saileshk
// CSCI 455 PA5
// Spring 2015

/*
 * grades.cpp
 * A program to test the Table class.
 * How to run it:
 *      grades [hashSize]
 * 
 * the optional argument hashSize is the size of hash table to use.
 * if it's not given, the program uses default size (Table::HASH_SIZE)
 *
 */

#include "Table.h"

// cstdlib needed for call to atoi
#include <cstdlib>


//insert the data provided by the user in the grade table.
void insertName(Table* &grades);

//change the score of a student to the value provided by the user.
void changeScore(Table* &grades);

//check if a student is present in the grade table.
void lookUpName(Table* &grades);

//remove a name and its score from the grade table.
void removeName(Table* &grades);

//print the command summary to run the program.
void printCmdSummary();

//do the thing for wrong command
void wrongCmd();

int main(int argc, char * argv[]) {

	// gets the hash table size from the command line

	int hashSize = Table::HASH_SIZE;
	
	string operation;
	bool quit = false;

	Table * grades;  // Table is dynamically allocated below, so we can call
                   // different constructors depending on input from the user.

	if (argc > 1) {
		hashSize = atoi(argv[1]);  // atoi converts c-string to int

		if (hashSize < 1) {
			cout << "Command line argument (hashSize) must be a positive number" << endl;
			return 1;
		}

		grades = new Table(hashSize);

	}
	else {   // no command line args given -- use default table size
		grades = new Table();
	}
	grades->hashStats(cout);
	
	while(quit == false){
		cout << "cmd>";
		cin >> operation;
		if(operation == "insert"){
			insertName(grades);
		}
		else if(operation == "change"){
			changeScore(grades);
		}
		else if(operation == "lookup"){
			lookUpName(grades);
		}
		else if(operation == "remove"){
			removeName(grades);
		}
		else if(operation == "print"){
			grades -> printAll();
		}
		else if(operation == "size"){
			cout << "The number of entries: " << grades -> numEntries() << endl;
		}
		else if(operation == "stats"){
			grades -> hashStats(cout);
		}
		else if(operation == "help"){
			printCmdSummary();
		}
		else if(operation == "quit"){
			quit = true;
		}		  
		else{
			wrongCmd();
		}
	}
	return 0;
}


void insertName(Table* &grades){
	
	string key;
	int value;
	cin >> key;
	cin >> value;	
	if(grades -> insert(key,value)){
		cout << " The name " << key << " and his/her score were inserted into the grade table" << endl;
	}
	else{
		cout << " The name" << key << " is already present" << endl;
	}
}	
  
	
void changeScore(Table* &grades){
	
	string key;
	int value;
	cin >> key;
	cin >> value;	  
	int* lookUpFound = grades -> lookup(key);
	if(lookUpFound == NULL){
		cout << " The name " << key << " is not found" << endl;
	}
	else{
		*lookUpFound = value;				// update the value in table with the given value
		cout << " The score of " << key << " was updated to " << value << endl;;
	}
}


void lookUpName(Table* &grades){

	string key;
	cin >> key;
	int* lookUpFound = grades -> lookup(key);
	if(lookUpFound == NULL){
		cout << " The name " << key << " is not found" << endl;
	}
	else{
		cout << " The score of " << key << " is " << *lookUpFound << endl;
	}
}


void removeName(Table* &grades){
	
	string key;
	cin >> key;
	bool removed = grades -> remove(key);
	if(removed == false){
		cout << " The name to be deleted is not found" << endl;
	}
	else{
		cout << " The name " << key << " and his/her score were deleted from the grade table"<< endl;
	}
}


void printCmdSummary(){
	
	cout << "VALID COMMANDS ARE:" << endl;
	cout << " insert name score	(Insert student with his/her score in the grade table)" << endl;
	cout << " change name newscore	(Change score of a student)" << endl;
	cout << " lookup name		(Print student's score)" << endl;
	cout << " remove name		(Remove student)" << endl;
	cout << " print			(Print all names and scores in the table)" << endl;
	cout << " size			(Print number of entries in the table)" << endl;
	cout << " stats			(Print statistics about the hash table)" << endl;
	cout << " help			(Print brief command summary)" << endl;
        cout << " quit			(Exit program)" << endl;
}


void wrongCmd(){
	
	cin.ignore(256,'\n');				//ignore the input buffer until user completes giving the wrong command 
	cout << "ERROR: invalid command" << endl;
	printCmdSummary();		  
}	

