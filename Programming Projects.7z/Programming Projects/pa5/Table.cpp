// Name:Sailesh Kumar Kumar
// Loginid:saileshk
// CSCI 455 PA5
// Spring 2015

// Table.cpp  Table class implementation


/*
 * Modified 11/22/11 by CMB
 *   changed name of constructor formal parameter to match .h file
 */

#include "Table.h"

#include <iostream>
#include <string>
#include <cassert>

//*************************************************************************
// Node class definition and member functions
//     You don't need to add or change anything in this section

// Note: we define the Node in the implementation file, because it's only
// used by the Table class; not by any Table client code.

struct Node {
	string key;
	int value;

	Node *next;

	Node(const string &theKey, int theValue);

	Node(const string &theKey, int theValue, Node *n);
};

Node::Node(const string &theKey, int theValue) {
	key = theKey;
	value = theValue;
	next = NULL;
}

Node::Node(const string &theKey, int theValue, Node *n) {
	key = theKey;
	value = theValue;
	next = n;
}

typedef Node * ListType;
                             

//*************************************************************************
//The hash Table is organized as a dynamic array (definied as arr) of ListType data
ListType* arr;

//insert an new pair into a list as pointed to by the arr table.
//return false if already present in the list(and no change is made to the list).
bool listInsert(ListType &list, const string &key, int value);

//returns the address of the value if key is present or NULL if key is not present in the list pointed to by the arr table.
//no change is made to the list.
int  *listLookup(ListType &list, const string &key);

//remove a pair n the list pointed to by the arr table.
//return false if key was not present in the list.
bool listRemove(ListType &list, const string &key);

Table::Table() {
	
	hashSize = HASH_SIZE;
	arr = new ListType[HASH_SIZE];
	for(int i = 0; i < HASH_SIZE; i++){
		arr[i] = NULL;
	}
}


Table::Table(unsigned int hSize) {
	
	hashSize = hSize;	
	arr = new ListType[hSize];
	for(int i = 0; i < hSize; i++){
		arr[i] = NULL;
	}
}


int * Table::lookup(const string &key) {
	
	int index = hashCode(key);
	return listLookup(arr[index],key);
}


bool Table::remove(const string &key) {
	
	int index = hashCode(key);
	return listRemove(arr[index],key);	 
}


bool Table::insert(const string &key, int value) {
	
	int index = hashCode(key);
	return listInsert(arr[index],key,value);  
}


int Table::numEntries() const {
	
	int count = 0;	
	for(int i = 0; i < hashSize; i++){
		if(arr[i] != NULL)
		  count = count + 1;
	}
    return count;  
}


void Table::printAll() const {
	
	if(numEntries() == 0){			// if Table is empty print <empty>
		cout << "<empty>" << endl;
	}		
	for(int i = 0; i < hashSize; i++){
		Node* p = arr[i];		
		while (p != NULL){
			cout << p -> key << " " << p -> value << endl;
			p = p-> next;
		}					
    }
}


void Table::hashStats(ostream &out) const {

	int totNum = 0;			//the variable that keeps track of total number of lists
	int longest = 0;		// the variable to hold the length of the longest chain
	int count;			// the temp variable to find the longest chain 
	for(int i = 0; i < hashSize; i++){
		count = 0;
		Node* p = arr[i];
		if(p != NULL){   
			while(p != NULL){
				p = p -> next;
				count++; 
				totNum++;
			}
		}
		if(count > longest){
			longest = count;
		}
	}
	out << "Number of buckets: " << hashSize << endl;
	out << "Number of entries: " << totNum << endl;
	out << "Number of non-empty entries: " << numEntries() << endl;
	out << "Longest chain: " << longest << endl; 
}
	
// add definitions for your private methods here

bool listInsert(ListType &list, const string &key, int value){
    
	Node* q = list;
    if(q == NULL){						// if an arr element is null, then a new Node is formed with the given element.
		Node* q = new Node(key, value);
		list = q;
		return true;
    }
    while(q !=  NULL){					// if the arr element already has the key, then no duplicate is added to the table.
		if((q -> key) == key){
			return false;
		}
		q = q -> next;
    }
    list = new Node(key, value, list);	// attach a new Node into the already existing list.
    /*p -> next = list;
    list = p;*/
    return true;
}


int  *listLookup(ListType &list, const string &key){
    
	Node* q = list;
    while(q != NULL){
       if((q -> key) == key){
		   return &(q -> value);
	   }
       q = q -> next;
    }
    return NULL;
} 


bool listRemove(ListType &list, const string &key){      
 
	if(list == NULL){
		return false;
	}
	Node *p = list;
	if((list -> key) == key){
		list = list -> next;
		delete p; 							//delete the unused part of the list to avoid memory leaks.
		return true;
	}
	while((p -> next) != NULL){   			
		if(((p -> next)-> key) == key){		//if the next Node's key is same as the one being looked for, delete that Node from the list.
			Node *q = p -> next;
			if((p -> next -> next )!= NULL){					
				p -> next = (p -> next -> next);
			}
			else{
				p -> next = NULL;				
			}
			delete q; 	 					//delete the omitted part of the list to avoid memory leaks.
			return true;
			}			
		p = p -> next;   		
	}
	return false;
}
/*
int  numEntries(ListType &list){
    Node* p = list;
    int i = 0;
    while(p != NULL){
	p = p -> next;
      i++; 
    }
    return i;
}

void  printAll(ListType &list){
    Node* p = list;
    if(p== NULL){
    cout << "<empty>" << endl;
    return ;
    }
    while (p != NULL){
	cout << p -> key << " " << p -> value << endl;
    p = p-> next;
    }cout<<endl;
}
*/
