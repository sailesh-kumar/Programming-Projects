// Name: Sailesh kumar kumar
// USC loginid: saileshk
// CSCI455 PA2
// Spring 2015
import java.util.Arrays;
import java.util.Scanner;


/*
 class SolitaireBoard
 The board for Bulgarian Solitaire.  You can change what the total number of cards is for the game
 by changing NUM_FINAL_PILES, below.  There are only some values for this that result in a game that terminates.
 (See comments below next to named constant declarations for more details on this.)
 */
public class SolitaireBoard {

    public static final int NUM_FINAL_PILES = 9;
   // number of piles in a final configuration
    // (note: if NUM_FINAL_PILES is 9, then CARD_TOTAL below will be 45)

    public static final int CARD_TOTAL = NUM_FINAL_PILES * (NUM_FINAL_PILES + 1) / 2;
   // bulgarian solitaire only terminates if CARD_TOTAL is a triangular number.
    // see: http://en.wikipedia.org/wiki/Bulgarian_solitaire for more details
    // the above formula is the closed form for 1 + 2 + 3 + . . . + NUM_FINAL_PILES

    /**
     * Representation invariant:<put rep. invar. comment here>
     *
     * 1. 0 < index_of_the_array < NUM_FINAL_PILES
     * 2. Sum of all values in the array is always equal to CARD_TOTAL 
     * 3. 0 < values in the array < the largest element in the initial array
     * 4.  numbers in the array are > 0
     * 5. if index_of_the_array = 1, then its only element is CARD_TOTAL 6. The
     * array is a space separated list of numbers.
     *
     */
    // <add instance variables here>
    private int[] solitaireBoard =null;

    /**
     * Initialize the board with the given configuration. PRE:
     * SolitaireBoard.isValidConfigString(numberString)
     */
    public SolitaireBoard(String numberString) {
        solitaireBoard = new int[CARD_TOTAL];
        Scanner string = new Scanner(numberString);
        int i = 0;
        while (string.hasNextInt()) {

            solitaireBoard[i] = string.nextInt();
            i++;
        }
        for(int j=0;j<solitaireBoard.length && solitaireBoard[j]!= 0; j++)
            System.out.println(solitaireBoard[j]);

        assert isValidSolitaireBoard();   // sample assert statement (you will be adding more of these calls)
    }

    /**
     * Create a random initial configuration.
     */
    public SolitaireBoard() {

        int MINIMUM_NUMBER_OF_PILES = 1;
        int sum = 0;
        int i = 0;
        int now;

        /*for (int i = 0;sum <= CARD_TOTAL; i++)*/
        do {
            now = MINIMUM_NUMBER_OF_PILES + (int) (Math.random() * (CARD_TOTAL + 1));
            sum += now;
            if (sum <= CARD_TOTAL) {
                solitaireBoard[i] = now;
                i++;
            }
            if (sum > CARD_TOTAL) {
                break;
            }

        } while (i <= CARD_TOTAL);
        if (solitaireBoard[i] == 0) {
            solitaireBoard[i] = CARD_TOTAL - sum + now;
        } else {
            solitaireBoard[i + 1] = CARD_TOTAL - sum + now;
        }
        assert isValidSolitaireBoard();

        /* for(int j = 0; j < solitaireBoard.length; j++){
         if(solitaireBoard[j]!= 0){
         System.out.print(solitaireBoard[j]);
         }
       
         } */
    }

    /**
     * Play one round of Bulgarian solitaire. Updates the configuration
     * according to the rules of Bulgarian solitaire: Takes one card from each
     * pile, and puts them all together in a new pile.
     */
    public void playRound() {
        int i;
        for (i = 0; i < solitaireBoard.length; i++) {
            if (solitaireBoard[i] != 0) {
                solitaireBoard[i] -= 1;
            } else {
                break;
            }
        }
        solitaireBoard[i] = i;
        System.out.println();
        int []temp = new int[solitaireBoard.length];
        int index = 0;
        for (int j = 0; j < solitaireBoard.length; j++) {
            if (solitaireBoard[j] != 0) {
                temp[index++] = solitaireBoard[j];
               
            }
        }
        solitaireBoard = temp;
        assert isValidSolitaireBoard();
        /*for(int j = 0; j < solitaireBoard.length; j++){
         if(solitaireBoard[j]!= 0){
         System.out.println(solitaireBoard[j]);               

         }
         }*/
    }

    /**
     * Return true iff the current board is at the end of the game. That is,
     * there are NUM_FINAL_PILES piles that are of sizes 1, 2, 3, . . . ,
     * NUM_FINAL_PILES, in any order.
     */
    /**
     * Return true iff the current board is at the end of the game.That is,
     * there are NUM_FINAL_PILES piles that are of sizes 1, 2, 3, . . . ,
     * NUM_FINAL_PILES, in any order.
     *
     * @return
     */
    public boolean isDone() {
        boolean []index=new boolean[NUM_FINAL_PILES];
        int count=0;
       
        for (int i = 0; i < solitaireBoard.length && solitaireBoard[i]!=0; i++) {
                if (solitaireBoard[i]<=NUM_FINAL_PILES && !index[solitaireBoard[i]-1]) {
                    
                    index[solitaireBoard[i]-1]=true;
                    count++;
                }
                else
                    return false;
            }
        assert isValidSolitaireBoard();
        return (count==NUM_FINAL_PILES);
    }

    /**
     * Returns current board configuration as a string with the format of a
     * space-separated list of numbers with no leading or trailing spaces. The
     * numbers represent the number of cards in each non-empty pile.
     */
    public String configString() {
        String solitaire = "";
        if (solitaireBoard[0]!=0)
           solitaire = String.valueOf(solitaireBoard[0]);
        for (int j = 1; j < solitaireBoard.length && solitaireBoard[j] != 0; j++) {
                solitaire+=" " + solitaireBoard[j];           
        }
        assert isValidSolitaireBoard();
        return solitaire;
    }

    /**
     * Returns true iff configString is a space-separated list of numbers that
     * is a valid Bulgarian solitaire board assuming the card total
     * SolitaireBoard.CARD_TOTAL PRE: configString must only contain numbers and
     * whitespace
     */
    public static boolean isValidConfigString(String configString) {
        String []numbers = configString.split(" ");
        int sum = 0;
        int temp = 0;
        for(int i = 0; i < numbers.length; i++){
            temp = Integer.parseInt(numbers[i]);
                if(temp <= 0){
                    return false;
                }
                sum += temp;
        }
        if (sum == SolitaireBoard.CARD_TOTAL)
        {
            return true;
        }
        return false;  // dummy code to get stub to compile

    }

    /**
     * Returns true iff the solitaire board data is in a valid state (See
     * representation invariant comment for more details.)
     */
    private boolean isValidSolitaireBoard() {
        return isValidConfigString(this.configString());

    }
    protected boolean Get_isValidSolitaireBoard()
    {
        return isValidSolitaireBoard();
    }

    // <add any additional private methods here>
}
