package bulgariansolitaire;

// Name:
// USC loginid:
// CSCI455 PA2
// Spring 2015


/*
   class SolitaireBoard
   The board for Bulgarian Solitaire.  You can change what the total number of cards is for the game
   by changing NUM_FINAL_PILES, below.  There are only some values for this that result in a game that terminates.
   (See comments below next to named constant declarations for more details on this.)
 */


public class SolitaireBoard {
   
   public static final int NUM_FINAL_PILES = 9;
   // number of piles in a final configuration
   // (note: if NUM_FINAL_PILES is 9, then CARD_TOTAL below will be 45)
   
   public static final int CARD_TOTAL = NUM_FINAL_PILES * (NUM_FINAL_PILES + 1) / 2;
   // bulgarian solitaire only terminates if CARD_TOTAL is a triangular number.
   // see: http://en.wikipedia.org/wiki/Bulgarian_solitaire for more details
   // the above formula is the closed form for 1 + 2 + 3 + . . . + NUM_FINAL_PILES
   
   /**
      Representation invariant:

      <put rep. invar. comment here>

    */
   
   // <add instance variables here>


 
   /**
     Initialize the board with the given configuration.
     PRE: SolitaireBoard.isValidConfigString(numberString)
   */
   public SolitaireBoard(String numberString) {


       assert isValidSolitaireBoard();   // sample assert statement (you will be adding more of these calls)
   }
 
   
   /**
      Create a random initial configuration.
   */
   public SolitaireBoard() {

   }
  
   
   /**
      Play one round of Bulgarian solitaire.  Updates the configuration according to the rules of Bulgarian
      solitaire: Takes one card from each pile, and puts them all together in a new pile.
    */
   public void playRound() {

   }
   

   /**
      Return true iff the current board is at the end of the game.  That is, there are NUM_FINAL_PILES
      piles that are of sizes 1, 2, 3, . . . , NUM_FINAL_PILES, in any order.
    */
   
   public boolean isDone() {
      
      return false;  // dummy code to get stub to compile
      
   }

   
   /**
      Returns current board configuration as a string with the format of
      a space-separated list of numbers with no leading or trailing spaces.
      The numbers represent the number of cards in each non-empty pile.
    */
   public String configString() {

      return "";   // dummy code to get stub to compile
   }

   
   /**
      Returns true iff configString is a space-separated list of numbers that
      is a valid Bulgarian solitaire board assuming the card total SolitaireBoard.CARD_TOTAL
      PRE: configString must only contain numbers and whitespace
   */
   public static boolean isValidConfigString(String configString) {

      return false;  // dummy code to get stub to compile
      
   }


   /**
      Returns true iff the solitaire board data is in a valid state
      (See representation invariant comment for more details.)
    */
   private boolean isValidSolitaireBoard() {
      
      return false;  // dummy code to get stub to compile

   }
   

    // <add any additional private methods here>


}