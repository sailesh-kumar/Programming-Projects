// Name: Sailesh kumar kumar
// USC loginid: saileshk
// CSCI455 PA2
// Spring 2015
import java.util.Scanner;




/**
   <add main program comment here>
 */

public class BulgarianSolitaireSimulator {

   public static void main(String[] args) {
       
       
      boolean singleStep = false;
      boolean userConfig = false;

      for (int i = 0; i < args.length; i++) {
         if (args[i].equals("-u")) {
            userConfig = true;
         }
         else if (args[i].equals("-s")) {
            singleStep = true;
            
         }
      }
      Scanner in = new Scanner(System.in);
      
      System.out.println("Number of total cards is 45\n" +
"You will be entering the initial configuration of the cards (i.e., how many in each pile).\n" +
"Please enter a space-separated list of positive integers followed by newline:");
      String input=null;
      while(!SolitaireBoard.isValidConfigString(input=in.nextLine()))
           System.out.println("ERROR: Each pile must have at least one card and the total number of cards must be 45\n" +
"Please enter a space-separated list of positive integers followed by newline:");
       SolitaireBoard sb = new SolitaireBoard(input);
       assert sb.Get_isValidSolitaireBoard();
       System.out.println("Initial configuration: " + sb.configString());
       System.out.println(sb.configString());
       int i=1;
       while(!sb.isDone()){
               sb.playRound();
               System.out.println("["+i+++"]Current configuration: "+sb.configString());
       }
        
           
      
   }
   
    // <add private static methods here>

  
}
