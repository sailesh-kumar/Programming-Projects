
import java.awt.BorderLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * MazeFrame
 *
 * JFrame for the maze program.
 *
 * Displays the status of the maze search and the maze itself with the path
 * through it once search is successful. Has a key listener that allows user to
 * initiate the maze search.
 *
 * Do not modify this file.
 *
 * Note: the listener class, MazeKeyListener, is an inner class. See below.
 */
public class MazeFrame extends JFrame {

    private JLabel searchStatusLabel;     // displays initial prompt and
    // the status of the search

    private MazeComponent mazeComponent;  // displays the maze and path

    private Maze maze;     // needed by component to access the data to display,
    // and by listener to initiate maze search.

    private static final int FRAME_WIDTH = 500;
    private static final int FRAME_HEIGHT = 500;

    private static final String PROMPT_STRING = "Type any key to start maze search . . . ";
    private static final String SUCCESS_STRING = "Found the way out!";
    private static final String FAIL_STRING = "No path out of maze.";

    /**
     * set up the gui components with the given maze data
     *
     * @param mazeData for details about what should be in this array see
     * Maze.java
     */
    public MazeFrame(int[][] mazeData) {

        setSize(FRAME_WIDTH, FRAME_HEIGHT);

        searchStatusLabel = new JLabel(PROMPT_STRING);
        add(searchStatusLabel, BorderLayout.NORTH); // put label at the top of the
        // frame
        maze = new Maze(mazeData);

        mazeComponent = new MazeComponent(maze);
        add(mazeComponent, BorderLayout.CENTER); // put maze display in the middle
        // of the frame

        KeyAdapter listener = new MazeKeyListener(); // defined below
        addKeyListener(listener); // process keyboard input
        setFocusable(true);

    }

    /**
     * getSearchMessage returns the message to display for a successful or
     * failed search.
     *
     * @param success whether the search succeeded
     * @return the string to display
     */
    private String getSearchMessage(boolean success) {
        if (success) {
            return SUCCESS_STRING;
        } else {
            return FAIL_STRING;
        }
    }

    class MazeKeyListener extends KeyAdapter { // inner class -- has access to outer
        // object's instance variables

        /**
         * keyPressed is called when the user types a character. The action
         * taken is to do the maze search, then update the display according to
         * the results of the search.
         *
         * @param event What the user typed. Ignored here.
         */
        public void keyPressed(KeyEvent event) {

            boolean success = maze.search();     // maze defined in enclosing MazeFrame

            mazeComponent.repaint();  // update drawing to show the results

            searchStatusLabel.setText(getSearchMessage(success));
        }
    }

}
