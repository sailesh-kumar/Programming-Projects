// Name:Sailesh Kumar Kumar
// USC loginid:saileshk
// CS 455 PA3
// Spring 2015
import static java.awt.Color.black;
import static java.awt.Color.blue;
import static java.awt.Color.green;
import java.awt.Graphics;
import java.util.LinkedList;
import java.util.ListIterator;
import javax.swing.JComponent;

/**
 * MazeComponent class
 *
 * A component that displays the maze and path through it if one has been found.
 */
public class MazeComponent extends JComponent {

    private Maze mazenew;
    private static final int START_X = 10;  // where to start drawing maze in frame
    private static final int START_Y = 10;  // (i.e., upper-left corner)

    private static final int BOX_WIDTH = 20;  // width and height of one maze unit
    private static final int BOX_HEIGHT = 20;

    /**
     * Constructs the component.
     *
     * @param maze the maze to display
     */
    public MazeComponent(Maze maze) {
        super();
        mazenew = maze;
    }

    /**
     * Draws the current state of maze including the path through it if one has
     * been found.
     *
     * @param g the graphics context
     */
    @Override
    public void paintComponent(Graphics g) {

        for (int i = 0; i < mazenew.numRows(); i++) {
            
            for (int j = 0; j < mazenew.numCols(); j++) {
                
                int free = mazenew.getValAt(new MazeCoord(i, j));
                
                if (free == 1) {
                    
                    g.setColor(black);
                    g.fillRect(START_Y + (j * BOX_HEIGHT), START_X + (i * BOX_WIDTH), BOX_WIDTH, BOX_HEIGHT);
                }
                if (i == mazenew.numRows() - 1 && j == mazenew.numCols() - 1) {
                   
                    if (free == 0) {
                        
                        g.setColor(green);
                        g.fillRect(START_Y + (j * BOX_HEIGHT), START_X + (i * BOX_WIDTH), BOX_WIDTH, BOX_HEIGHT);
                    }
                }

            }
        }
        g.setColor(black);
        g.drawRect(START_Y, START_X, mazenew.numCols() * BOX_HEIGHT, mazenew.numRows() * BOX_WIDTH);

        LinkedList<MazeCoord> list = mazenew.getPath();
        if(list == null){
            return;
        }
        ListIterator iterator = list.listIterator();
        
        while (iterator.hasNext()) {
            
            MazeCoord start = (MazeCoord) iterator.next();
            MazeCoord last = null;
            if (iterator.hasNext()) {
                
                last = (MazeCoord) iterator.next();
                iterator.previous();
                g.setColor(blue);
                g.drawLine(start.getCol() * BOX_HEIGHT + BOX_WIDTH/2  + START_Y, start.getRow()* BOX_HEIGHT + BOX_WIDTH/2 + START_X, last.getCol()* BOX_HEIGHT + BOX_WIDTH/2  + START_Y, last.getRow() * BOX_HEIGHT + BOX_WIDTH/2 + START_X);
            }
        }
    }
}
